"""spaceflights
"""

__version__ = "0.1"

from kedro.framework.project import run, configure_project

configure_project("spaceflights")
