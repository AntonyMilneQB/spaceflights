"""spaceflights
"""

__version__ = "0.1"

from __main__ import main
