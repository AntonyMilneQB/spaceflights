"""Complete Data Processing pipeline for the spaceflights tutorial"""

from .pipeline import create_pipeline  # NOQA
